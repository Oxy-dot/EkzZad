﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestProject
{
	public partial class Test : Form
	{
		public static string pathToFile = "C:\\Users\\User\\Desktop\\ПРАКТИКА МОДУЛЬ ПЕРВЫЙ\\";
		public static string nazv;
		public static int countQuestions;
		public int countTestQuestion = 0;
		public String question;
		public int variant;
		public String answerOption;
		public String answerOptionTwo;
		public String answerOptionThree;
		public String answerOptionFour;
		public static int rightAnswer;
		public static int countRightAnswer;
		StreamReader reader;
		StreamWriter sw;
		String fio;

		public Test()
		{
			InitializeComponent();
			fio = Fio.fio;
		}

		private void Test_Load(object sender, EventArgs e)
		{
			radioButton1.Checked = false;
			radioButton2.Checked = false;
			radioButton3.Checked = false;
			radioButton4.Checked = false;

			if (!(File.ReadAllLines(pathToFile+ "test.txt").Length < 6))
			{
				reader = new StreamReader(pathToFile + "test.txt");
				countQuestions = CountQuestions();
				label2.Text = Convert.ToString(countTestQuestion + 1);
				label3.Text = Question();
				radioButton1.Text = AnswerOption();
				radioButton2.Text = AnswerOption();
				radioButton3.Text = AnswerOption();
				radioButton4.Text = AnswerOption();
				rightAnswer = RightAnswer();
				if (countTestQuestion == countQuestions) button1.Text = "Завершить";
			}
			else
			{
				Error error = new Error();
				this.Hide();
				error.Show();
			}
		}

		private int CountQuestions()
		{
			return File.ReadAllLines(pathToFile + "test.txt").Length / 6 - 1;
		} 

		private String Question()
		{
			for (int i = 0; i < countTestQuestion * 6 + 1; i++)
			{
				question = reader.ReadLine();
			}
			return question;
		}

		private String AnswerOption()
		{
			answerOption = reader.ReadLine();
			return answerOption;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			radioButton1.Checked = false;
			radioButton2.Checked = false;
			radioButton3.Checked = false;
			radioButton4.Checked = false;

			nazv = pathToFile + (fio.Replace(".", "")).Replace(" ", "") + ".txt";
			sw = new StreamWriter(nazv, true);

			if (variant == rightAnswer) countRightAnswer += 1;

			sw.WriteLine("Вопрос: " + (countTestQuestion + 1) + "  ||  Вариант ответа: " + variant);
			sw.Close();
			if (countTestQuestion < countQuestions)
			{
				countTestQuestion += 1;
				reader = new StreamReader(pathToFile + "test.txt");
				countQuestions = CountQuestions();
				label2.Text = Convert.ToString(countTestQuestion + 1);
				label3.Text = Question();
				radioButton1.Text = AnswerOption();
				radioButton2.Text = AnswerOption();
				radioButton3.Text = AnswerOption();
				radioButton4.Text = AnswerOption();
				rightAnswer = RightAnswer();
				if (countTestQuestion == countQuestions) button1.Text = "Завершить";
			}
			else
			{
				Result result = new Result();
				this.Hide();
				result.Show();
			}

			if (!radioButton1.Checked && !radioButton2.Checked && !radioButton3.Checked && !radioButton3.Checked)
			{
				button1.Enabled = false;
			}
		}

		private int RightAnswer()
		{
			rightAnswer = Convert.ToInt32(reader.ReadLine());
			return rightAnswer;
		}

		private void button2_Click(object sender, EventArgs e)
		{

			if (MessageBox.Show("Вы уверены, что хотите выйти?", "Предупрждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
			{
				nazv = pathToFile + (fio.Replace(".", "")).Replace(" ", "") + ".txt";
				sw = new StreamWriter(nazv, true);
				sw.WriteLine("Тест заверщен досрочно.");
				sw.Close();
				Result result = new Result();
				this.Hide();
				result.Show();
			}
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			variant = 1;
			button1.Enabled = true;
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			variant = 2;
			button1.Enabled = true;
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			variant = 3;
			button1.Enabled = true;
		}

		private void radioButton4_CheckedChanged(object sender, EventArgs e)
		{
			variant = 4;
			button1.Enabled = true;

		}

		private void Test_FormClosing(object sender, FormClosingEventArgs e)
		{
			nazv = pathToFile + (fio.Replace(".", "")).Replace(" ", "") + ".txt";
			sw = new StreamWriter(nazv, true);
			sw.WriteLine("Вопрос: " + (countTestQuestion + 1) + "  ||  Вариант ответа: " + variant);
			sw.WriteLine("Тест заверщен досрочно.");
			sw.Close();
		}
	}
}
