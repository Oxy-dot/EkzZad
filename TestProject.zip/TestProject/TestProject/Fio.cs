﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace TestProject
{
	public partial class Fio : Form
	{
		private bool hasTextBeenTyped;
		public static String fio;
		StreamWriter sw;
		public static string pathToFile = "C:\\Users\\User\\Desktop\\ПРАКТИКА МОДУЛЬ ПЕРВЫЙ\\";
		public static string nazv;

		public Fio()
		{
			InitializeComponent();
		}

		private void Fio_Load(object sender, EventArgs e)
		{
			textBox1.Text = "Фамилия И.О.";
			textBox1.ForeColor = Color.DimGray;
		}


		private void textBox1_TextChanged_1(object sender, EventArgs e)
		{
			hasTextBeenTyped = !String.IsNullOrEmpty(textBox1.Text);

			if (hasTextBeenTyped)
			{
				textBox1.ForeColor = Color.Black;
			}
		}

		private void textBox1_Click_1(object sender, EventArgs e)
		{
			if (textBox1.Text == "Фамилия И.О.") textBox1.Text = "";
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (Regex.IsMatch(textBox1.Text, @"^[A-ЯЁ]{1}[а-яё]+\s+[A-ЯЁ]{1}\.[A-ЯЁ]{1}\.+$") && (textBox1.Text != "Фамилия И.О."))
			{
				DateTime thisDay = DateTime.Now;
				fio = textBox1.Text;
				nazv = pathToFile + (fio.Replace(".", "")).Replace(" ", "") + ".txt";
				if (File.Exists(nazv))
				{
					sw = new StreamWriter(nazv, true);
					sw.WriteLine();
					sw.WriteLine("----------------------------------------------------------");
					sw.WriteLine("Новая попытка. Тест сделан " + thisDay.ToString());
				}
				else
				{
					sw = new StreamWriter(nazv, false);
					sw.WriteLine("Тест сделан " + thisDay.ToString());
					sw.WriteLine("Фамилия: " + fio);
				}
				sw.Close();
				Test testForm = new Test();
				this.Hide();
				testForm.Show();
			}
			else errorProvider1.SetError(textBox1, "Некорректное заполнение данных");
		}

		private void textBox1_KeyPress_1(object sender, KeyPressEventArgs e)
		{
			hasTextBeenTyped = true;
			char l = e.KeyChar;
			if ((l < 'A' || l > 'z') && (l < 'А' || l > 'я') && l != '\b' && l != '.' && l != ' ')
			{
				e.Handled = true;
			}
		}
	}
}
