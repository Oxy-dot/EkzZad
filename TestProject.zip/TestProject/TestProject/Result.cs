﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestProject
{

	public partial class Result : Form
	{
		public int countQuestion;
		public int rightAnswer;
		public int ochenka;
		public String nazv;
		StreamWriter sw;

		public Result()
		{
			InitializeComponent();
			countQuestion = Test.countQuestions + 1;
			rightAnswer = Test.countRightAnswer;
			nazv = Fio.nazv;
		}

		private void Result_Load(object sender, EventArgs e)
		{
			label3.Text = Convert.ToString(countQuestion);
			label5.Text = Convert.ToString(rightAnswer);
			label7.Text = Convert.ToString(Ochenka(rightAnswer, countQuestion));
			sw = new StreamWriter(nazv, true);
			sw.WriteLine("Оценка за тест: " + ochenka);
			sw.Close();
			switch (ochenka)
			{
				case 2: label7.ForeColor = Color.DarkRed; break;
				case 3: label7.ForeColor = Color.Chocolate; break;
				case 4: label7.ForeColor = Color.DarkGoldenrod; break;
				case 5: label7.ForeColor = Color.DarkGreen; break;
			}
		}

		private int Ochenka(int r_answer, int c_answer)
		{
			double prochent = Prochent(r_answer, c_answer);
			if (prochent < 50) ochenka = 2;
			else if (prochent < 70) ochenka = 3;
			else if (prochent < 85) ochenka = 4;
			else ochenka = 5;
			return ochenka;
		}

		private double Prochent(int r_answer, int c_answer)
		{
			double x = r_answer * 100 / c_answer;
			return Math.Round(x);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			DateTime thisDay = DateTime.Now;
			sw = new StreamWriter(nazv, true);
			sw.WriteLine();
			sw.WriteLine("----------------------------------------------------------");
			sw.WriteLine("Новая попытка. Тест сделан " + thisDay.ToString());
			sw.Close();
			this.Close();
			Test.countRightAnswer = 0;
			Test test = new Test();
			test.Show();
			
		}
	}
}
