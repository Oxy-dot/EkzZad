﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
    }
        public int p = 0;
        private void button1_Click(object sender, EventArgs e)
        {            
            int kol = Convert.ToInt32(textBox1.Text);
            for (int i = 0; i != kol; i++)
            {

                Random rnd = new Random();
                int h = rnd.Next(200, 800);
                int w = rnd.Next(0, 1000);

                int s_h = rnd.Next(0, 250);
                int s_w = rnd.Next(0, 250);

                var pictureTest1 = new PictureBox();

                void nukio(object sendera, MouseEventArgs g)
                {                    
                    if (g.Button == MouseButtons.Right)
                    {
                        this.Controls.Remove(pictureTest1);

                        Console.WriteLine("Удалил");
                    }
                    if (g.Button == MouseButtons.Left)
                    {
                        Image flipImage = pictureTest1.Image;
                        flipImage.RotateFlip(RotateFlipType.Rotate90FlipXY);
                        pictureTest1.Image = flipImage;
                        Console.WriteLine("Поворот");
                    }                    
                }

                Random rnd_img = new Random();
                int img_num = rnd_img.Next(1, 4);
                switch (img_num)
                {
                    case 1:
                        pictureTest1.Image = Image.FromFile("D:/WindowsFormsApp1/img/photo1.jpg");
                        break;
                    case 2:
                        pictureTest1.Image = Image.FromFile("D:/WindowsFormsApp1/img/photo2.jpg");
                        break;
                    case 3:
                        pictureTest1.Image = Image.FromFile("D:/WindowsFormsApp1/img/photo3.jpg");
                        break;
                }
                
                pictureTest1.Location = new Point(w, h);
                pictureTest1.Name = "spawn1";
                pictureTest1.Size = new Size(s_w, s_h);
                pictureTest1.TabIndex = 98;
                pictureTest1.TabStop = false;
                pictureTest1.MouseClick += new MouseEventHandler(nukio);

                this.Controls.Add(pictureTest1);                
            }
        }

    }   
}
