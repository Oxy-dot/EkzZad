﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    
    abstract class Client
    {
        public long Inn { get; set; }
        public string Address { get; set; }
        public Client(long inn, string address)
        {
            Inn = inn;
            Address = address;
        }
    
        public abstract void GetInfo();
    }

    class Natural : Client
    {
        public string Fio { get; set; }
        public string Pol { get; set; }
        public int God_r { get; set; }
        public Natural(string fio, string pol, int god_r, long inn, string address): base(inn, address)
        {
            Fio = fio;
            Pol = pol;
            God_r = god_r;
        }
        
        public override void GetInfo()
        {
            Console.WriteLine($"ФИО: {Fio}\nПол: {Pol}\nГод рождения: {God_r}\nИНН: {base.Inn}\nАдрес: {base.Address}\n");
        }
    }

    class Legal : Client
    {
        public string Name { get; set; }
        public string Forma { get; set; }
        public int God_s { get; set; }
        public Legal(string name, string forma, int god_s, long inn, string address) : base(inn, address)
        {
            Name = name;
            Forma = forma;
            God_s = god_s;
        }
        
        public override void GetInfo()
        {
            Console.WriteLine($"Название организации: {Name}\nОрганизационно-правовая форма: {Forma}\nГод создания: {God_s}\nИНН: {base.Inn}\nАдрес: {base.Address}\n");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Client> clients = new List<Client>();
            clients.Add(new Legal("Обувь", "Хозяйственные товарищества", 2018, 7727563778, "г.Москва, Цветной б-р, 16"));
            clients.Add(new Natural("Петров Петр Петрович", "мужской", 1988, 7727563755, "г.Санкт-Петербург, Финляндский пр., 1, кв.101"));
            clients.Add(new Natural("Иванова Алиса Петровна", "женский", 1995, 7757463755, "г.Ярославль, ул.Колотушкина, д.Пушкинаб, кв.30"));
            clients.Add(new Legal("Научно-исследовательский институт машиностроения", "Унитарное предприятие", 2008, 7727561112, "г.Брест, ул.Пушкина, д.Колотушкина"));

            foreach (Client client in clients)
                client.GetInfo();
            
            Console.ReadLine();
        }
    }
}
