﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ConsoleApp3
{
	class Program
	{
		static void Main(string[] args)
		{
			
			string file_directory_in = "C:\\Users\\79116\\Desktop\\input.txt";
			string file_directory_out = "C:\\Users\\79116\\Desktop\\output.txt";
			bool Error = false;

			try
			{
				StreamReader sr = new StreamReader(file_directory_in);
				StreamWriter sw = new StreamWriter(file_directory_out);
				string result = "";
				string line = "";
				while (!sr.EndOfStream)
				{
					line = sr.ReadLine();
					if(line != "")
					{
						string[] lines = line.Split();

						for (int i = 0; i < lines.Length; i++)
						{
							if (lines[i].Length > 0)
							{
								result += lines[i][0];
							}
						}
					}
					else
					{
						Console.WriteLine("Найдена пустая строка, проверьте текстовый файл");
						Error = true;
						break;	
						
					}
					
				}
				sw.WriteLine(result);
				sr.Close();
				sw.Close();

				if(Error is false)
				{
					try
					{
						StreamReader streamReader = new StreamReader(file_directory_out);
						while (streamReader.Read() != -1)
						{

							Console.WriteLine(streamReader.ReadLine());
						}
						streamReader.Close();
						Console.WriteLine("Все было успешно");
					}
					catch (Exception et)
					{
						Console.WriteLine(et.Message);
						Console.WriteLine("Чтение не удалось");
					}
				}
				else
				{
					Console.WriteLine("Возникла ошибка");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Console.WriteLine("Возникла ошибка");
			}
			Console.ReadKey();
		}
	}
		
}
