﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iz
{
    public partial class Form1 : Form
    {
        int sumtovar;
        double sumskidka;
        double kassa;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sumtov.Text = Convert.ToString(0);
            sumskid.Text = Convert.ToString(0);
            kass.Text = Convert.ToString(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sumtovar = +Convert.ToInt32(cena.Text) * Convert.ToInt32(kolichestvo.Text);
            sumtov.Text = Convert.ToString(Convert.ToInt32(sumtov.Text) + sumtovar);

            sumskidka = +(Convert.ToInt32(skidka.Text) * 0.01) * sumtovar;
            sumskid.Text = Convert.ToString(Convert.ToDouble(sumskid.Text) + sumskidka);

            kassa = +((sumtovar-sumskidka) * 0.13) + (sumtovar - sumskidka);
            kass.Text = Convert.ToString(Math.Round(Convert.ToDouble(kass.Text) + kassa, 2));

            try
            {
                int stoim = Convert.ToInt32(cena.Text) * Convert.ToInt32(kolichestvo.Text);
                double skid = (Convert.ToInt32(skidka.Text) *0.01) * stoim;
                double stskid = stoim - skid;
                double nds = Math.Round(0.13 * stskid, 2);
                double itog = stskid + nds;

                richTextBox1.SelectedText = "Вы преобрели товар: " + name.Text + "\n";
                richTextBox1.SelectedText = "По цене: " + cena.Text + "\n";
                richTextBox1.SelectedText = "Стоимость товара: " + stoim + "\n";
                richTextBox1.SelectedText = "Величина скидки: " + skid + "\n";
                richTextBox1.SelectedText = "Стоимость со скидкой: " + stskid + "\n";
                richTextBox1.SelectedText = "НДС(13%): " + nds + "\n";
                richTextBox1.SelectedText = "Итого за товар: " + itog + "\n";
                richTextBox1.SelectedText = "\n";
                richTextBox1.SelectedText = "\n";
                
            }
            catch
            {
                MessageBox.Show("Проверьте правильность введенных данных и повторите попытку!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            sumtov.Text = Convert.ToString(0);
            sumskid.Text = Convert.ToString(0);
            kass.Text = Convert.ToString(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionStart = 0;
            richTextBox1.SelectionLength = 0;
            richTextBox1.SelectedText = DateTime.Now.ToString() + "\n";

            richTextBox1.SaveFile("D:/test.txt", System.Windows.Forms.RichTextBoxStreamType.PlainText);


            Application.Exit();
        }
    }
}
