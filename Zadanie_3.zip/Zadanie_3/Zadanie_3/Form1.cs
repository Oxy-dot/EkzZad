﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && number != 8 && number != 44) //цифры, клавиша BackSpace и запятая а ASCII
            {
                e.Handled = true;
            }

            if (e.KeyChar == '.')
                e.KeyChar = ','; //замена точки на запятую
            if (e.KeyChar == ',')
            {
                if (((sender as TextBox).Text.IndexOf(',') != -1) //запятая уже есть
                    || (sender as TextBox).Text.Length == 0) //число не введено
                    e.Handled = true;
                return;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && number != 8 && number != 44) //цифры, клавиша BackSpace и запятая а ASCII
            {
                e.Handled = true;
            }

            if (e.KeyChar == '.')
                e.KeyChar = ','; //замена точки на запятую
            if (e.KeyChar == ',')
            {
                if (((sender as TextBox).Text.IndexOf(',') != -1) //запятая уже есть
                    || (sender as TextBox).Text.Length == 0) //число не введено
                    e.Handled = true;
                return;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8) // цифры и клавиша BackSpace
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double growth, growthpr, weight, imt, kol, kol2;
            string mass = "";
            int age = 0;
            kol = 0;
            kol2 = 0;


            if(textBox1.Text.Length == 0 || textBox2.Text.Length == 0)
            {
                MessageBox.Show("Вы не ввели рост или вес!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
            else
            {
                growth = Convert.ToDouble(textBox1.Text);
                weight = Convert.ToDouble(textBox2.Text);
                growthpr = growth / 100;

                imt = weight / (growthpr * growthpr);
                imt = Math.Round(imt, 1);

                if(imt < 18.5)
                {
                    mass = "Дефицит массы тела"; 
                }
                else if (imt >= 18.5 && imt <= 24.9) {
                    mass = "Нормальная масса тела";
                }
                else if (imt >= 25 && imt <= 29.9)
                {
                    mass = "Избыточная масса тела";
                }
                else if (imt >= 30 && imt <= 34.9)
                {
                    mass = "Ожирение 1-ой степени";
                }
                else if (imt >= 35 && imt <= 39.9)
                {
                    mass = "Ожирение 2-ой степени";
                }
                else if (imt >= 40)
                {
                    mass = "Ожирение 3-ей степени";
                }

                //MessageBox.Show(mass.ToString(), "asdfas");

                if (textBox3.Text.Length == 0)
                {
                    MessageBox.Show("Вы не ввели возраст!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    age = Convert.ToInt32(textBox3.Text);
                }

                if (radioButton1.Checked == false && radioButton2.Checked == false)
                {
                    MessageBox.Show("Вы не выбрали пол!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (radioButton1.Checked == true)
                    {
                        kol = 66 + (13.7 * weight) + (5 * growth) - (6.8 * age);
                    }
                    else if (radioButton2.Checked == true) {
                        kol = 65 + (9.6 * weight) + (1.8 * growth) - (4.7 * age);
                    }

                    //MessageBox.Show(kol.ToString(), "asd");

                    if (comboBox1.SelectedIndex == -1)
                    {
                        MessageBox.Show("Вы не выбрали, на сколько вы физически активны!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (comboBox1.SelectedIndex == 0)
                        {
                            kol2 = kol * 1.2;
                        }
                        else if (comboBox1.SelectedIndex == 1)
                        {
                            kol2 = kol * 1.38;
                        }
                        else if (comboBox1.SelectedIndex == 2)
                        {
                            kol2 = kol * 1.56;
                        }
                        else if (comboBox1.SelectedIndex == 3)
                        {
                            kol2 = kol * 1.73;
                        }
                        else if (comboBox1.SelectedIndex == 4)
                        {
                            kol2 = kol * 1.95;
                        }

                        //MessageBox.Show(kol.ToString(), "asd");
                        MessageBox.Show("Тип массы тела: " + mass + "\n" +
                            "Калорийность суточного рациона: " + kol + "\n" +
                            "Расход калорий: " + kol2, 
                            "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }

                }
            }

        }

        
    }
}
