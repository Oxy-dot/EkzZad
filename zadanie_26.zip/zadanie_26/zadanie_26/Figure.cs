﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_26
{
    public class Figure
    {
        public double X;
        public virtual double Square()
        {
            return X;
        }
    }

    public class Rectangle : Figure
    {
        public double Y;
        public override double Square()
        {
            return X*Y;
        }

    }

    public class Circle : Figure
    {
        
        public override double Square()
        {
            return Math.PI * X * X;
        }

    }

}
