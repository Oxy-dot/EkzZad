﻿// See https://aka.ms/new-console-template for more information
using zadanie_26;

Rectangle R = new Rectangle();
Circle C = new Circle();
R.X = 10;
R.Y = 10;
C.X = 10;

Console.WriteLine(R.Square());
Console.WriteLine(C.Square());