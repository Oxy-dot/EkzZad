﻿using System;


namespace ПриложениеОтчет
{
    class University
    {
        public string name_un { get; set; }
        public string adres_un { get; set; }
        public University(string name, string Adres)
        {
            name_un = name;
            adres_un = Adres;
        }
        public virtual void Print()
        {
            Console.WriteLine($"Название университета: {name_un}" + "\n" + $"Его адрес: {adres_un}");
        }
    }
    class Fac : University
    {
        public string name_fac { get; set; }
        public string FIO_dec { get; set; }
        public Fac(string name, string Adres, string name_f, string FIO_d) : base(name, Adres)
        {
            name_fac = name_f;
            FIO_dec = FIO_d;
            
        }
        public override void Print()
        {
            base.Print();
            Console.WriteLine($"Факультет: {name_fac} " + "\n" + $"ФИО декана: {FIO_dec}");
        }
    }
    class Kaf: Fac
    {
        public string name_kaf { get; set; }
        public string FIO_kaf { get; set; }
        public Kaf(string name, string Adres, string name_f, string FIO_d, string name_k, string FIO_k) : base(name, Adres,name_f, FIO_d)
        {
            name_kaf = name_k;
            FIO_kaf = FIO_k;
        }
        public override void Print()
        {
            base.Print();
            Console.WriteLine($"Название кафедры: {name_kaf}" + "\n" + $"ФИО заведующего кафедры: {FIO_kaf}");
        }
    }
    class MainClass
    {
        public static void Main (string[] args)
        {
            string Univ, Inf;
            Console.WriteLine("Какой университет вас интересует?");
            Univ = Console.ReadLine();
            if (Univ == "Чешский")
            {
                Console.WriteLine("Вам интересен университет, факультет или кафедра?");
                Inf = Console.ReadLine();
                if (Inf == "Университет" || Inf == "университет")
                {
                    Console.WriteLine("Тест университета");
                    University white = new University("Чешский", "Ул. Чешская, 26");
                    white.Print();
                }
                if (Inf == "Факультет" || Inf == "факультет")
                {
                    Console.WriteLine("\n" + "Тест факультета");
                    Fac lol = new Fac("Чешский", "Ул. Чешская, 26", "Педагогический", "Васильев Илья Олегович");
                    lol.Print();
                }
                if (Inf == "Кафедра" || Inf == "кафедра")
                {
                    Console.WriteLine("\n" + "Тест кафедры");
                    Kaf kek = new Kaf("Чешский", "Ул. Чешская, 26", "Педагогический", "Васильев Илья Олегович", "Русский язык", "Беспалов Николай Палыч");
                    kek.Print();
                }
                if (Inf != "Кафедра" & Inf != "Факультет" & Inf != "Университет" & Inf != "кафедра" & Inf != "факультет" & Inf != "университет")
                {
                    Console.WriteLine("Такой информации нет");
                }
            }
            if (Univ == "Белый")
            {
                Console.WriteLine("Вам интересен университет, факультет или кафедра?");
                Inf = Console.ReadLine();
                if (Inf == "Университет" || Inf == "университет")
                {
                    Console.WriteLine("Тест университета");
                    University white = new University("Белый", "Ул. Белая, 1");
                    white.Print();
                }
                if (Inf == "Факультет" || Inf == "факультет")
                {
                    Console.WriteLine("\n" + "Тест факультета");
                    Fac lol = new Fac("Белый", "Ул. Белая, 1", "Информационный", "Веткин Павел Александрович");
                    lol.Print();
                }
                if (Inf == "Кафедра" || Inf == "кафедра")
                {
                    Console.WriteLine("\n" + "Тест кафедры");
                    Kaf kek = new Kaf("Белый", "Ул. Белая, 1", "Информационный", "Веткин Павел Александрович", "Информатика", "Александров Вадим Дмитривич");
                    kek.Print();
                }
                if(Inf != "Кафедра" & Inf != "Факультет" & Inf != "Университет" & Inf != "кафедра" & Inf != "факультет" & Inf != "университет")
                {
                    Console.WriteLine("Такой информации нет");
                }
            }
            if(Univ != "Чешский" & Univ != "Белый")
            {
                Console.WriteLine("Такого университета нет");
            }
            Console.ReadKey();
        }
    }
}
