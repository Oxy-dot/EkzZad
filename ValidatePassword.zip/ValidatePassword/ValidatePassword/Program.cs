﻿using System;
using System.Text.RegularExpressions;


namespace ValidatePassword
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Требования к паролю" + "\n" +
                "Длина пароля: от 4 до 10 символов;" + "\n" + 
                "Может содержать: произвольные латинские буквы, цифру и знак подчеркивания;" + "\n" +
                "Не должен начинаться с цифры;" + "\n" +
                "Одна цифра должна быть обязательно;" + "\n" +
                "Знак подчеркивания может отсутствовать или быть только один." + "\n");
            Console.Write("Введите пароль: ");
            var password = Console.ReadLine();
            password = password.ToLower();
            var passwordValidate = new Regex(@"^(?=.*[a-z])(?=.*[a-z])(?=.*[0-9])(?=.*[_]?)\S{4,10}$");
            if (passwordValidate.IsMatch(password))
            {
                char[] passwordChar = password.ToCharArray();
                var count = 0;
                Console.WriteLine("Ваш пароль: " + password);
                foreach (char a in passwordChar)
                {
                    passwordChar[count] = (char)(a + 1);
                    count++;
                }

                Console.WriteLine("Зашифрованный пароль: " + new String(passwordChar));
            }

            else
                Console.Write("Пароль не соответствует заданным требованиям!");

            Console.ReadKey();
            
        }
    }
}
