﻿using Newtonsoft.Json.Linq;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            await HTTPReq();

        }
        static async Task HTTPReq()
        {
           
            HttpClient client = new HttpClient();

            HttpResponseMessage response = (await client.GetAsync("https://data.townofcary.org/api/records/1.0/search/?dataset=points-of-interest&q=&facet=owner&facet=owntype&facet=featurecode&facet=descript")).EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();

            JObject jObject = JObject.Parse(responseBody);
            JArray array = (JArray)jObject["records"];

            var result = array.Select(a => new
            {
                DataSetID = (string)a["datasetid"],
                RecordID = (string)a["recordid"],
                Fields  = new {
                    FeatureCode = (string)a["fields"]["featurecode"],
                    Name = (string)a["fields"]["name"],
                    GeoShape = new
                    {
                        Coordinates = new
                        {
                            CoordinateX = (string)a["fields"]["geo_shape"]["coordinates"][0],
                            CoordinateY = (string)a["fields"]["geo_shape"]["coordinates"][1]
                        },
                        Type = (string)a["fields"]["geo_shape"]["type"]
                    },
                    
                },
                GeoPoint2d = new
                {
                    Point2dX = (string)a["fields"]["geo_point_2d"][0],
                    Point2dY = (string)a["fields"]["geo_point_2d"][1]
                },
                Owner = (string)a["fields"]["owner"],
                Owntype = (string)a["fields"]["owntype"],
                FullAddr = (string)a["fields"]["fulladdr"],
                Descript = (string)a["fields"]["descript"],
                Geometry = new { 
                   Type = (string)a["geometry"]["type"],
                   Coordinates = new
                   {
                       CoordinateX = (string)a["geometry"]["coordinates"][0],
                       CoordinateY = (string)a["geometry"]["coordinates"][1]
                   }
                },
                RecordTimeStamp = (string)a["record_timestamp"]
            }).ToList();

            foreach (var item in result)
                Console.WriteLine(item);
        }   
    }
}