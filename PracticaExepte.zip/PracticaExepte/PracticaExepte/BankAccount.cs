﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaExepte
{
    internal class BankAccount
    {
        static long amountBankAccount = 0; 

        private long numberBankAccount; // Номер банковского счета
        private string dateOpenAccount; // Дата открытия 
        private string FIO;             // ФИО владельца
        private long sumOnAccount = 0;  // Количество денег
        private int monthOnDeposit;     // Месяцев для депозита

        private bool statusBankAccount = false;  // Статус счета, по дефолту он закрыт
        private string dateCloseAccount;         // Дата закрытия

        public BankAccount (string FIO, long sumOnAccount, int monthOnDeposit)
        {
            this.numberBankAccount = amountBankAccount + 1;
            this.dateOpenAccount = DateTime.Now.Date.ToString();
            this.FIO = FIO;
            this.sumOnAccount = sumOnAccount;
            this.monthOnDeposit = monthOnDeposit;
            amountBankAccount++;
        }

        public void OpenBankAccount ()
        {
            this.statusBankAccount = true;
            this.dateOpenAccount = DateTime.Now.Date.ToString();
            Console.WriteLine("Счет открыт");
        }

        public void CloseBankAccount ()
        {
            this.statusBankAccount = false; 
            this.dateCloseAccount = DateTime.Now.Date.ToString();
            Console.WriteLine("Счет закрыт");
        }

        public void SubAllSumOnAccount ()
        {
            this.sumOnAccount = 0;
            Console.WriteLine("Все деньги были сняты");
        }

        public void DisplayAllInfo()
        {
            Console.WriteLine($"Номер счета: {this.numberBankAccount}");
            Console.WriteLine($"Статус действия счета: {this.statusBankAccount}");
            Console.WriteLine($"ФИО Владельца: {this.FIO}");
            Console.WriteLine($"Дата открытия: {this.dateOpenAccount}");
            Console.WriteLine($"Сумма на вкладе: {this.sumOnAccount}");
            Console.WriteLine($"Длительность вклада: {this.monthOnDeposit}");
        }

        public void AddSumOnAccount(long sum)
        {
            if (this.statusBankAccount)
            {
                this.sumOnAccount += sum;
                Console.WriteLine("Деньги были положены");
            } else
            {
                Console.WriteLine("Счет заблокирован");
            }
        }

        public void SubSumOnAccount(long sum)
        {
            if (sum > 0)
            {
                if (this.statusBankAccount && this.sumOnAccount - sum >= 0)
                {
                    this.sumOnAccount -= sum;
                    Console.WriteLine("Деньги были сняты");
                }
                else
                {
                    Console.WriteLine("Счет заблокирован");
                }
            }
        }

        public void TransactionOnAccount (BankAccount bank, long sum)
        {
            if (this.sumOnAccount - sum >= 0 && bank.statusBankAccount && this.statusBankAccount)
            {
                this.sumOnAccount -= sum;
                bank.sumOnAccount += sum;
                Console.WriteLine($"Перевод был совершен на имя: {bank.FIO}");
            } else
            {
                Console.WriteLine("Перевод был отменен. У вас недостаточно средств, или счет закрыт");
            }
        }
    }
}
