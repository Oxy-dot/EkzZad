﻿
using PracticaExepte;

BankAccount bankAccGusev = new BankAccount("Гусев Анатолий Михайлович", 12000, 12);
BankAccount bankAccBoshina = new BankAccount("Бошина Божена Юрьевна", 25000, 4);

bankAccBoshina.OpenBankAccount();
bankAccGusev.OpenBankAccount();

bankAccGusev.DisplayAllInfo();
bankAccBoshina.DisplayAllInfo();

bankAccGusev.AddSumOnAccount(21400);
bankAccBoshina.SubSumOnAccount(12000);

bankAccGusev.DisplayAllInfo();
bankAccBoshina.DisplayAllInfo();

bankAccBoshina.TransactionOnAccount(bankAccGusev, 10000);