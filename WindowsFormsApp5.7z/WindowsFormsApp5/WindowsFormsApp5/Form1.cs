﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        string pol;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();

            f2.name = textBox1.Text;
            f2.fam = textBox2.Text;
            f2.addres = textBox3.Text;
            f2.date_r = dateTimePicker1.Text;
            f2.benefits = comboBox1.Text;
            f2.pol = pol;

            f2.age = 2022 - dateTimePicker1.Value.Year;
            Console.WriteLine(dateTimePicker1.Value.Year);
            f2.Show();
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = (RadioButton)sender;
            if (radioButton.Checked)
            {
                pol = radioButton.Text;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
