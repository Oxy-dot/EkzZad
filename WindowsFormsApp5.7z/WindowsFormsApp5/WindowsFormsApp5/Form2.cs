﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form2 : Form
    {
        public string name;
        public string fam;
        public string date_r;
        public string addres;
        public string pol;
        public string benefits;
        public int age;

        public Form2()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = fam + " " + name;
            label2.Text = "Дата рождения " + date_r;
            label3.Text = "Пол: " + pol;
            label4.Text = "Пенсионные льготы: " + benefits;

            if (pol == "М")
                label5.Text = "До пенсии осталось: " + (65 - age) + " лет";
            else
                label5.Text = "До пенсии осталось: " + (63 - age) + " лет";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
